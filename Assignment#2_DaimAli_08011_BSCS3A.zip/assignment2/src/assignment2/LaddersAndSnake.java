package assignment2;

import java.util.*;

public class LaddersAndSnake {

    /**
     * @param args the command line arguments
     */
    public static int winVar = 0;
    
    // this function is used to modify the score in the game, when:
    // * the snake mouth is at the tail of the snake
    // * the snake mouth is at the start of the ladder

    public static int[] snakesAndLaddersCheck(int recent_status, int snake_array[][], int ladder_array[][]) {

        int Change_status = 0;
        int Change_reason[] = new int[2];
        int Snakes_count = snake_array.length;
        int Ladder_count = ladder_array.length;

        // in this loop, i actually checks for snake_array
        int d=0;
        while(d < Snakes_count) {
            if (snake_array[d][0] == recent_status) {
                System.out.println("You are at snake_array head!!");
                Change_status = snake_array[d][1];
                Change_reason[0] = Change_status;
                Change_reason[1] = 0;              //this line represents snake modified score
                return Change_reason;
            }
            d++;
        }

        // in this loop, i actually checks for ladder_array
        int i=0;
        while(i < Ladder_count){
            if (ladder_array[i][0] == recent_status) {
                System.out.println("You are at ladder_array start!!");
                Change_status = ladder_array[i][1];
                Change_reason[0] = Change_status;
                Change_reason[1] = 1;//represents ladder_array modified score
                return Change_reason;

            }
            i++;
        }
        // here, if there is  no ladder or snake is present then return same position
        Change_reason[0] = recent_status;
        Change_reason[1] = -1;         // this line represents snake modified score
        return Change_reason;

    }
    
    // this the main class which actually calling the different functions returns the number of the rounds.
       //like: maximim number of rounds, minimum number of rounds or avrege number of rounds

    public static int snakesAndLaddersGame() {

       int win = 0;
        winVar = 0;
        int board[];
        int Players_count;

        // the queue data structure is used for turning of the players
        Queue<Integer> Turning_player;     
        int recent_player = 0;
        int result;
        int Round_count[];

        int recent_status[];
       int Snakes_blocked[];

        int[][] snake_array;
        int[][] ladder_array;

        board = new int[100];

        //here in this loop all the repetition occurrs about 100 times.
        int j=0;
        while(j < 100)
         {
            board[j] = j + 1; //make board and print it on screen
            j++;
        }

        // here i have declared the number of players: 
        // that number can be:- random, 2 or 4
        Players_count = (int) (Math.random() * (5 - 2)) + 2;
        //Players_count = 4;
        //making queue for players turn
        
        // here the queue is being using linked list

        Turning_player = new LinkedList<Integer>();
        
        // in this loop the players are pushed into the queue
        int z=1;
        while(z <= Players_count){
            //push players in queue
            Turning_player.add(z);
            z++;
        }

        recent_status = new int[Players_count];
        Snakes_blocked = new int[Players_count];
        Round_count = new int[Players_count];

        // here in this loop is used for initialization
        int k=0;
        while(k < Players_count) {
            recent_status[k] = 1;
            Snakes_blocked[k] = 0;
            Round_count[k] = 0;
            k++;
        }

        // snake_array position at specified location
        snake_array = new int[5][2];

        snake_array[0][0] = 24;
        snake_array[0][1] = 12;
        snake_array[1][0] = 37;
        snake_array[1][1] = 20;
        snake_array[2][0] = 54;
        snake_array[2][1] = 40;
        snake_array[3][0] = 77;
        snake_array[3][1] = 65;
        snake_array[4][0] = 95;
        snake_array[4][1] = 80;

      //ladder_array position at specified location
        ladder_array = new int[5][2];
        ladder_array[0][0] = 4;
        ladder_array[0][1] = 14;
        ladder_array[1][0] = 30;
        ladder_array[1][1] = 41;
        ladder_array[2][0] = 31;
        ladder_array[2][1] = 55;
        ladder_array[3][0] = 50;
        ladder_array[3][1] = 72;
        ladder_array[4][0] = 78;
        ladder_array[4][1] = 94;

        int[] game_result = new int[2];

       int new_chance = 0;

     // this loop will run until the game is not win condition. 
        while (win !=1) {

            System.out.println("\n");
            //pop the queue to get current player
            if (new_chance!=1) {
                recent_player = Turning_player.poll();
                Round_count[recent_player - 1] += 1;
            }

            new_chance = 0;

            System.out.println("turn : player " + recent_player);
            //possible result     
            result = (int) (Math.random() * (7 - 1)) + 1;
            System.out.println("result of dice =  " + result);

            if (result == 6) {
                new_chance =1;
            }

            //here in this conditional statement i check whether the output is exceeded from 100
            if (recent_status[recent_player - 1] + result > 100) {
                do {
                    System.out.println("output exceeded 100");
                    if (result != 6 ) {    // if the output is not equal to 6
                        Turning_player.add(recent_player);//pushed recent_player into queue

                        recent_player = Turning_player.poll();//pop another player
                        Round_count[recent_player - 1] += 1;
                    }

                    System.out.println("turn : player " + recent_player);
                    //possible result     
                    result = (int) (Math.random() * (7 - 1)) + 1;
                    if (result == 6) {
                        new_chance =1;
                    }
                    System.out.println("result of dice =  " + result);
                } while (result + recent_status[recent_player - 1] > 100);
            }

            // here i checks either the snake is bitten the person or not
            if (Snakes_blocked[recent_player - 1]!=1) {

               
                //conditions for snake
                recent_status[recent_player - 1] += result;

                if (recent_status[recent_player - 1] == 100) {
                    System.out.println("Hurrah Player " + recent_player + " is winner!!");
                    win =1;
                    winVar =1;

                }

               
                //check for the snake_array and ladder position, and decrese  or increase the score according to that
                game_result = snakesAndLaddersCheck(recent_status[recent_player - 1], snake_array, ladder_array);
                recent_status[recent_player - 1] = game_result[0];

                if (game_result[1] == -1) {
                    System.out.println("Now player " + recent_player + " position = " + recent_status[recent_player - 1]);
                }
                if (game_result[1] == 0) { //due to snake score is decreased 
                    Snakes_blocked[recent_player - 1] =1;
                    System.out.println("Now player " + recent_player + " position = " + recent_status[recent_player - 1]);
                }
                if (game_result[1] == 1) { //due to ladder position increased
                    new_chance =1;
                    System.out.println("Now player " + recent_player + " position = " + recent_status[recent_player - 1]);
                }

            }

            //if blocked by snake and its result comes to be 6 free it
            if (Snakes_blocked[recent_player - 1]==1 && result == 6) {
                Snakes_blocked[recent_player - 1] = 0;
                new_chance =1;
            }

            if (new_chance == 0) {
                Turning_player.add(recent_player);
            }

        }
        // printing the totla number of the rounds.
        System.out.println("TotalRounds" + Round_count[recent_player - 1]);

        return Round_count[recent_player - 1];
    }

    public static void main(String[] args) {

        int Round_count[];
        Round_count = new int[100];
        
        int j=0;
        // in this loop the elements are inserted into array
        while(j<100) {
            System.out.println("  ***********WELCOME TO SNAKES AND LADDERS*********");
            Round_count[j] = snakesAndLaddersGame();
            j++;

        }
        
        // in this loop, the array is printed
        int z=0;
        while(z< 100) {
            System.out.println(Round_count[z]);
            z++;

        }
        //these statements prints the requirements of the program.
        LongSummaryStatistics statistics = Arrays.stream(Round_count).asLongStream().summaryStatistics();
        System.out.println("The average rounds of all games are: " + (int) statistics.getAverage());
        System.out.println("Highest: Rounds " + statistics.getMax());
        System.out.println("Lowest: Rounds " + statistics.getMin());
        double currentMemory = ((double) ((double) (Runtime.getRuntime().totalMemory() / 1024) / 1024)) - ((double) ((double) (Runtime.getRuntime().freeMemory() / 1024) / 1024));
        System.out.println("Current Memory: " + currentMemory);
      
    }

}

