package assignment2;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * 
 */
public class LaddersAndSnakeTest {

    /**
     * Test of snakesAndLaddersCheck method, of class LaddersAndSnake.
     */
    @Test
    public void testSnakesAndLaddersCheck() {
        System.out.println("snake_array And Ladders condition checks");
        int recent_status = 0;

        int[][] snake_array;
        int[][] ladder_array;
        snake_array = new int[5][2];

        snake_array[0][0] = 25;
        snake_array[0][1] = 13;
        snake_array[1][0] = 40;
        snake_array[1][1] = 24;
        snake_array[2][0] = 60;
        snake_array[2][1] = 35;
        snake_array[3][0] = 85;
        snake_array[3][1] = 70;
        snake_array[4][0] = 98;
        snake_array[4][1] = 78;

        ladder_array = new int[5][2];
        ladder_array[0][0] = 2;
        ladder_array[0][1] = 11;
        ladder_array[1][0] = 15;
        ladder_array[1][1] = 29;
        ladder_array[2][0] = 31;
        ladder_array[2][1] = 55;
        ladder_array[3][0] = 50;
        ladder_array[3][1] = 72;
        ladder_array[4][0] = 80;
        ladder_array[4][1] = 92;
        
        //checking snake_array whether working properly or not
        
        // checking the snake array by giving the expected output and the given result of program.
        recent_status = 25;

        int[] output_expected = new int[2];
        output_expected[0] = 13;
        output_expected[1] = 0;

        int[] result = LaddersAndSnake.snakesAndLaddersCheck(recent_status, snake_array, ladder_array);
        assertArrayEquals(output_expected, result);

        recent_status = 60;
        output_expected[0] = 35;
        output_expected[1] = 0;

        result = LaddersAndSnake.snakesAndLaddersCheck(recent_status, snake_array, ladder_array);
        assertArrayEquals(output_expected, result);

        // now checking that ladder_array condition checking, by giving the expected output and the given result of program.
        recent_status = 2;
        output_expected[0] = 11;
        output_expected[1] = 1;

        result = LaddersAndSnake.snakesAndLaddersCheck(recent_status, snake_array, ladder_array);
        assertArrayEquals(output_expected, result);

        recent_status = 80;
        output_expected[0] = 92;
        output_expected[1] = 1;

        result = LaddersAndSnake.snakesAndLaddersCheck(recent_status, snake_array, ladder_array);
        assertArrayEquals(output_expected, result);

        recent_status = 58;
        output_expected[0] = 58;
        output_expected[1] = -1;

        result = LaddersAndSnake.snakesAndLaddersCheck(recent_status, snake_array, ladder_array);
        assertArrayEquals(output_expected, result);

    }

    /**
     * Test of snakesAndLaddersGame method, of class LaddersAndSnake.
     */
    @Test(timeout = 2000)
    // here we checks whether any round is played or not
    public void testSnakesAndLaddersGame() {
        
        System.out.println("snakesAndLaddersGame");
       
        int output_expected = 0;
        int result = LaddersAndSnake.snakesAndLaddersGame();
        assertNotEquals(output_expected, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");

        //test the winning condition
        LaddersAndSnake winCheck = new LaddersAndSnake();
        //boolean expected = true;  
        int result2 = winCheck.snakesAndLaddersGame();
        assertEquals(1,winCheck.winVar);

    }

}


